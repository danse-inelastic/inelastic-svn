/*
 * Some file constants for the application settings
 *
 * Copyright (C) 2005-2008 Yves Zoundi
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * under the License.
 */
package net.sf.vfsjfilechooser.constants;

import java.io.File;


/**
 * Some file constants for the application settings
 * @author Yves Zoundi <yveszoundi at users dot sf dot net>
 * @version 0.0.1
 */
public final class VFSJFileChooserConstants
{
    /**
     * The user directory
     */
    public static final File HOME_DIRECTORY = new File(System.getProperty("user.home"));

    /**
     * The settings directory
     */
    public static final File CONFIG_DIRECTORY = new File(HOME_DIRECTORY, ".vfsjfilechooser");

    /**
     * The bookmarks file
     */
    public static final File BOOKMARKS_FILE = new File(CONFIG_DIRECTORY, "favorites.xml");
}
