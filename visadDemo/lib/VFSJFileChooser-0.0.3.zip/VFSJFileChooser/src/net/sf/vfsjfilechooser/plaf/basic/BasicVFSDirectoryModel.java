/*
 *
 * Copyright (C) 2005-2008 Yves Zoundi
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * under the License.
 */
package net.sf.vfsjfilechooser.plaf.basic;

import java.awt.EventQueue;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

import javax.swing.AbstractListModel;

import net.sf.vfsjfilechooser.VFSJFileChooser;
import net.sf.vfsjfilechooser.filechooser.AbstractVFSFileSystemView;
import net.sf.vfsjfilechooser.plaf.AbstractVFSFileChooserUI;
import net.sf.vfsjfilechooser.plaf.metal.MetalVFSFileChooserUI;
import net.sf.vfsjfilechooser.utils.FileObjectComparatorFactory;

import org.apache.commons.vfs.FileObject;
import org.apache.commons.vfs.FileSystemException;


/**
 * The DirectoryModel implementation based on Swing BasicDirectoryModel
 * @author Yves Zoundi <yveszoundi at users dot sf dot net>, Jason Harrop <jasonharrop at users.sourceforge.net>
 * @version 0.0.1
 */
@SuppressWarnings("serial")
public class BasicVFSDirectoryModel extends AbstractListModel
    implements PropertyChangeListener
{
    private static final Comparator<FileObject> fileNameComparator = FileObjectComparatorFactory.newFileNameComparator(true);
    private VFSJFileChooser filechooser = null;
    private final Vector<FileObject> fileCache = new Vector<FileObject>(50);
    private LoadFilesThread loadThread = null;
    private List<FileObject> files = null;
    private List<FileObject> directories = null;
    private int fetchID = 0;
    private PropertyChangeSupport changeSupport;
    private boolean busy = false;

    /**
     *
     * @param filechooser
     */
    public BasicVFSDirectoryModel(VFSJFileChooser filechooser)
    {
        this.filechooser = filechooser;
        validateFileCache();
    }

    /**
     *
     * @param e
     */
    public void propertyChange(PropertyChangeEvent e)
    {
        String prop = e.getPropertyName();

        if ((prop.equals(VFSJFileChooser.DIRECTORY_CHANGED_PROPERTY)) ||
                (prop.equals(VFSJFileChooser.FILE_VIEW_CHANGED_PROPERTY)) ||
                (prop.equals(VFSJFileChooser.FILE_FILTER_CHANGED_PROPERTY)) ||
                (prop.equals(VFSJFileChooser.FILE_HIDING_CHANGED_PROPERTY)) ||
                (prop.equals(
                    VFSJFileChooser.FILE_SELECTION_MODE_CHANGED_PROPERTY)))
        {
            validateFileCache();
        }
        else if ("UI".equals(prop))
        {
            Object old = e.getOldValue();

            if (old instanceof BasicVFSFileChooserUI)
            {
                BasicVFSFileChooserUI ui = (BasicVFSFileChooserUI) old;
                BasicVFSDirectoryModel model = ui.getModel();

                if (model != null)
                {
                    model.invalidateFileCache();
                }
            }
        }
        else if ("JFileChooserDialogIsClosingProperty".equals(prop))
        {
            invalidateFileCache();
        }
    }

    /**
     * This method is used to interrupt file loading thread.
     */
    public void invalidateFileCache()
    {
        if (loadThread != null)
        {
            loadThread.interrupt();
            loadThread.cancelRunnables();
            loadThread = null;
        }
    }

    /**
     *
     * @return
     */
    public List<FileObject> getFiles()
    {
        synchronized (fileCache)
        {
            if (files != null)
            {
                return files;
            }

            final int mid = fileCache.size() >> 1;

            files = new Vector<FileObject>(mid);
            directories = new Vector<FileObject>(mid);

            FileObject currentDir = filechooser.getCurrentDirectory();
            AbstractVFSFileSystemView v = filechooser.getFileSystemView();
            directories.add(v.createFileObject(currentDir, ".."));

            for (FileObject f : fileCache)
            {
                if (filechooser.isTraversable(f))
                {
                    directories.add(f);
                }
                else
                {
                    files.add(f);
                }
            }

            return files;
        }
    }

    /**
     *
     */
    public void validateFileCache()
    {
        FileObject currentDirectory = filechooser.getCurrentDirectory();

        if (currentDirectory == null)
        {
            return;
        }

        try
        {
            currentDirectory.refresh();
        }
        catch (FileSystemException ex)
        {
        }

        if (loadThread != null)
        {
            loadThread.interrupt();
            loadThread.cancelRunnables();
        }

        setBusy(true, ++fetchID);

        loadThread = new LoadFilesThread(currentDirectory, fetchID);
        loadThread.start();
    }

    /**
     * Renames a file in the underlying file system.
     *
     * @param oldFile a <code>File</code> object representing
     *        the existing file
     * @param newFile a <code>File</code> object representing
     *        the desired new file name
     * @return <code>true</code> if rename succeeded,
     *        otherwise <code>false</code>
     * @since 1.4
     */
    public boolean renameFile(FileObject oldFile, FileObject newFile)
    {
        synchronized (fileCache)
        {
            try
            {
                oldFile.moveTo(newFile);
                validateFileCache();

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
    }

    /**
     *
     */
    public void fireContentsChanged()
    {
        fireContentsChanged(this, 0, getSize() - 1);
    }

    public int getSize()
    {
        return fileCache.size();
    }

    /**
     *
     * @param o
     * @return
     */
    public boolean contains(Object o)
    {
        return fileCache.contains(o);
    }

    /**
     * @param o
     * @return
     */
    public int indexOf(Object o)
    {
        return fileCache.indexOf(o);
    }

    /* (non-Javadoc)
     * @see javax.swing.ListModel#getElementAt(int)
     */
    public Object getElementAt(int index)
    {
        return fileCache.get(index);
    }

    /**
     * @param comparator
     */
    public void sort(Comparator<FileObject> comparator)
    {
        Collections.sort(fileCache, comparator);
    }

    /**
     *
     * @param v
     */
    protected void sort(List<FileObject> v)
    {
        Collections.sort(v, fileNameComparator);
    }

    /**
     * Adds a PropertyChangeListener to the listener list. The listener is
     * registered for all bound properties of this class.
     * <p>
     * If <code>listener</code> is <code>null</code>,
     * no exception is thrown and no action is performed.
     *
     * @param    listener  the property change listener to be added
     *
     * @see #removePropertyChangeListener
     * @see #getPropertyChangeListeners
     *
     * @since 1.6
     */
    public void addPropertyChangeListener(PropertyChangeListener listener)
    {
        if (changeSupport == null)
        {
            changeSupport = new PropertyChangeSupport(this);
        }

        changeSupport.addPropertyChangeListener(listener);
    }

    /**
     * Removes a PropertyChangeListener from the listener list.
     * <p>
     * If listener is null, no exception is thrown and no action is performed.
     *
     * @param listener the PropertyChangeListener to be removed
     *
     * @see #addPropertyChangeListener
     * @see #getPropertyChangeListeners
     *
     * @since 1.6
     */
    public void removePropertyChangeListener(PropertyChangeListener listener)
    {
        if (changeSupport != null)
        {
            changeSupport.removePropertyChangeListener(listener);
        }
    }

    /**
     * Returns an array of all the property change listeners
     * registered on this component.
     *
     * @return all of this component's <code>PropertyChangeListener</code>s
     *         or an empty array if no property change
     *         listeners are currently registered
     *
     * @see      #addPropertyChangeListener
     * @see      #removePropertyChangeListener
     * @see      java.beans.PropertyChangeSupport#getPropertyChangeListeners
     *
     * @since 1.6
     */
    public PropertyChangeListener[] getPropertyChangeListeners()
    {
        if (changeSupport == null)
        {
            return new PropertyChangeListener[0];
        }

        return changeSupport.getPropertyChangeListeners();
    }

    /**
     * Support for reporting bound property changes for boolean properties.
     * This method can be called when a bound property has changed and it will
     * send the appropriate PropertyChangeEvent to any registered
     * PropertyChangeListeners.
     *
     * @param propertyName the property whose value has changed
     * @param oldValue the property's previous value
     * @param newValue the property's new value
     *
     * @since 1.6
     */
    protected void firePropertyChange(String propertyName, Object oldValue,
        Object newValue)
    {
        if (changeSupport != null)
        {
            changeSupport.firePropertyChange(propertyName, oldValue, newValue);
        }
    }

    /**
     * Set the busy state for the model. The model is considered
     * busy when it is running a separate (interruptable)
     * thread in order to load the contents of a directory.
     */
    private synchronized void setBusy(final boolean busy, int fid)
    {
        if (fid == fetchID)
        {
            boolean oldValue = this.busy;
            this.busy = busy;

            if ((changeSupport != null) && (busy != oldValue))
            {
                EventQueue.invokeLater(new Runnable()
                    {
                        public void run()
                        {
                            firePropertyChange("busy", !busy, busy);
                        }
                    });
            }
        }
    }

    class LoadFilesThread extends Thread
    {
        // private FileObject currentDirectory = null;
        private int fid;
        private Vector<DoChangeContents> runnables = new Vector<DoChangeContents>(10);

        public LoadFilesThread(FileObject currentDirectory, int fid)
        {
            super("Basic L&F File Loading Thread");
            this.fid = fid;
            setPriority(Thread.MIN_PRIORITY);
        }

        private void invokeLater(DoChangeContents runnable)
        {
            runnables.add(runnable);
            EventQueue.invokeLater(runnable);
        }

        public void run()
        {
            run0();
            setBusy(false, fid);
        }

        public void run0()
        {
            AbstractVFSFileSystemView fileSystem = filechooser.getFileSystemView();

            FileObject cwd = filechooser.getCurrentDirectory();

            // fix a bug here when the filesystem changes, the directories list needs to be notified
            if (!contains(cwd))
            {
                AbstractVFSFileChooserUI ui = filechooser.getUI();
                ((MetalVFSFileChooserUI) ui).getCombo().setSelectedItem(cwd);
            }

            FileObject[] list = fileSystem.getFiles(cwd,
                    filechooser.isFileHidingEnabled());

            List<FileObject> acceptsList = new Vector<FileObject>(list.length);

            if (isInterrupted())
            {
                return;
            }

            // run through the file list, add directories and selectable files to fileCache
            for (FileObject aFileObject : list)
            {
                if (filechooser.accept(aFileObject))
                {
                    acceptsList.add(aFileObject);
                }
            }

            if (isInterrupted())
            {
                return;
            }

            // First sort alphabetically by filename
            sort(acceptsList);

            final int mid = acceptsList.size() >> 1;

            List<FileObject> newDirectories = new Vector<FileObject>(mid);
            List<FileObject> newFiles = new Vector<FileObject>(mid);

            // run through list grabbing directories in chunks of ten
            for (FileObject f : acceptsList)
            {
                boolean isTraversable = filechooser.isTraversable(f);

                if (isTraversable)
                {
                    newDirectories.add(f);
                }
                else
                {
                    newFiles.add(f);
                }

                if (isInterrupted())
                {
                    return;
                }
            }

            List<FileObject> newFileCache = new Vector<FileObject>(newDirectories);
            newFileCache.addAll(newFiles);

            int newSize = newFileCache.size();
            int oldSize = fileCache.size();

            if (newSize > oldSize)
            {
                //see if interval is added
                int start = oldSize;
                int end = newSize;

                for (int i = 0; i < oldSize; i++)
                {
                    if (!newFileCache.get(i).equals(fileCache.get(i)))
                    {
                        start = i;

                        for (int j = i; j < newSize; j++)
                        {
                            if (newFileCache.get(j).equals(fileCache.get(i)))
                            {
                                end = j;

                                break;
                            }
                        }

                        break;
                    }
                }

                if ((start >= 0) && (end > start) &&
                        newFileCache.subList(end, newSize)
                                        .equals(fileCache.subList(start, oldSize)))
                {
                    if (isInterrupted())
                    {
                        return;
                    }

                    invokeLater(new DoChangeContents(newFileCache.subList(
                                start, end), start, null, 0, fid));
                    newFileCache = null;
                }
            }
            else if (newSize < oldSize)
            {
                //see if interval is removed
                int start = -1;
                int end = -1;

                for (int i = 0; i < newSize; i++)
                {
                    if (!newFileCache.get(i).equals(fileCache.get(i)))
                    {
                        start = i;
                        end = (i + oldSize) - newSize;

                        break;
                    }
                }

                if ((start >= 0) && (end > start) &&
                        fileCache.subList(end, oldSize)
                                     .equals(newFileCache.subList(start, newSize)))
                {
                    if (isInterrupted())
                    {
                        return;
                    }

                    invokeLater(new DoChangeContents(null, 0,
                            new Vector<FileObject>(fileCache.subList(start, end)),
                            start, fid));
                    newFileCache = null;
                }
            }

            if ((newFileCache != null) && !fileCache.equals(newFileCache))
            {
                if (isInterrupted())
                {
                    cancelRunnables(runnables);
                }

                invokeLater(new DoChangeContents(newFileCache, 0, fileCache, 0,
                        fid));
            }
        }

        public void cancelRunnables(List<DoChangeContents> runnables)
        {
            for (DoChangeContents runnable : runnables)
            {
                runnable.cancel();
                runnable = null;
            }
        }

        public void cancelRunnables()
        {
            cancelRunnables(runnables);
        }
    }

    class DoChangeContents implements Runnable
    {
        private List<FileObject> addFiles;
        private List<FileObject> remFiles;
        private boolean doFire = true;
        private int fid;
        private int addStart = 0;
        private int remStart = 0;

        public DoChangeContents(List<FileObject> addFiles, int addStart,
            List<FileObject> remFiles, int remStart, int fid)
        {
            this.addFiles = addFiles;
            this.addStart = addStart;
            this.remFiles = remFiles;
            this.remStart = remStart;
            this.fid = fid;
        }

        synchronized void cancel()
        {
            doFire = false;
        }

        public synchronized void run()
        {
            if ((fetchID == fid) && doFire)
            {
                int remSize = (remFiles == null) ? 0 : remFiles.size();
                int addSize = (addFiles == null) ? 0 : addFiles.size();

                synchronized (fileCache)
                {
                    if (remSize > 0)
                    {
                        fileCache.removeAll(remFiles);
                    }

                    if (addSize > 0)
                    {
                        fileCache.addAll(addStart, addFiles);
                    }

                    files = null;
                    directories = null;
                }

                if ((remSize > 0) && (addSize == 0))
                {
                    fireIntervalRemoved(BasicVFSDirectoryModel.this, remStart,
                        (remStart + remSize) - 1);
                }
                else if ((addSize > 0) && (remSize == 0) &&
                        (fileCache.size() > addSize))
                {
                    fireIntervalAdded(BasicVFSDirectoryModel.this, addStart,
                        (addStart + addSize) - 1);
                }
                else
                {
                    fireContentsChanged();
                }
            }
        }
    }
}
