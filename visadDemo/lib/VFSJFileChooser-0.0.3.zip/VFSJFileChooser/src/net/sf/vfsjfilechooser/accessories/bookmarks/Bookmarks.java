/*
 *
 * Copyright (C) 2005-2008 Yves Zoundi
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * under the License.
 */
package net.sf.vfsjfilechooser.accessories.bookmarks;

import net.sf.vfsjfilechooser.constants.VFSJFileChooserConstants;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;


/**
 * The bookmarks table model
 * @author Dirk Moebius (JEdit)
 * @author Yves Zoundi <yveszoundi at users dot sf dot net>
 * @version 0.0.1
 */
public class Bookmarks extends AbstractTableModel
{
    private static final long serialVersionUID = 6142063286592461932L;
    private static final String nameColumnTitle = "Name";
    private static final String urlColumnTitle = "URL";
    private List<TitledURLEntry> entries = Collections.synchronizedList(new ArrayList<TitledURLEntry>());

    /**
     *
     */
    public Bookmarks()
    {
        if (!VFSJFileChooserConstants.CONFIG_DIRECTORY.exists())
        {
            if (!VFSJFileChooserConstants.CONFIG_DIRECTORY.mkdirs())
            {
                System.err.println("Unable to create config directory");
            }
        }

        List<TitledURLEntry> values = load();

        for (TitledURLEntry entry : values)
        {
            add(entry);
        }
    }

    /**
     * @param e
     */
    public void add(TitledURLEntry e)
    {
        entries.add(e);
        fireTableRowsInserted(entries.size() - 1, entries.size() - 1);
    }

    /**
     * @return
     */
    public int getSize()
    {
        return entries.size();
    }

    /**
     * @param index
     * @return
     */
    public String getTitle(int index)
    {
        TitledURLEntry e = getEntry(index);

        return (e == null) ? null : e.getTitle();
    }

    /**
     * @param index
     * @return
     */
    public String getURL(int index)
    {
        TitledURLEntry e = getEntry(index);

        return (e == null) ? null : e.getURL();
    }

    /**
     * @param index
     * @return
     */
    public TitledURLEntry getEntry(int index)
    {
        if ((index < 0) || (index > entries.size()))
        {
            return null;
        }

        TitledURLEntry e = entries.get(index);

        return e;
    }

    /**
     * @param row
     */
    public void delete(int row)
    {
        entries.remove(row);
        fireTableRowsDeleted(row, row);
    }

    /**
     * @param row
     */
    public void moveup(int row)
    {
        if (row == 0)
        {
            return;
        }

        TitledURLEntry b = getEntry(row);
        entries.remove(row);
        entries.add(row - 1, b);
        fireTableRowsUpdated(row - 1, row);
    }

    public void movedown(int row)
    {
        if (row == (entries.size() - 1))
        {
            return;
        }

        TitledURLEntry b = getEntry(row);
        entries.remove(row);
        entries.add(row + 1, b);
        fireTableRowsUpdated(row, row + 1);
    }

    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#getColumnCount()
     */
    public int getColumnCount()
    {
        return 2;
    }

    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#getRowCount()
     */
    public int getRowCount()
    {
        return entries.size();
    }

    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     */
    public Object getValueAt(int row, int col)
    {
        Object obj = null;

        if (row < entries.size())
        {
            if (col == 0)
            {
                obj = getEntry(row).getTitle();
            }
            else if (col == 1)
            {
                obj = getEntry(row).getURL();
            }
        }

        return obj;
    }

    /* (non-Javadoc)
     * @see javax.swing.table.AbstractTableModel#isCellEditable(int, int)
     */
    public boolean isCellEditable(int row, int col)
    {
        return true;
    }

    /* (non-Javadoc)
     * @see javax.swing.table.AbstractTableModel#setValueAt(java.lang.Object, int, int)
     */
    public void setValueAt(Object value, int row, int col)
    {
        TitledURLEntry e = getEntry(row);

        if (col == 0)
        {
            e.setTitle(value.toString());
        }
        else if (col == 1)
        {
            e.setURL(value.toString());
        }

        fireTableRowsUpdated(row, row);
    }

    /* (non-Javadoc)
     * @see javax.swing.table.AbstractTableModel#getColumnName(int)
     */
    public String getColumnName(int index)
    {
        return (index == 0) ? nameColumnTitle : urlColumnTitle;
    }

    @SuppressWarnings("unchecked")
    public List<TitledURLEntry> load()
    {
        File favorites = VFSJFileChooserConstants.BOOKMARKS_FILE;

        try
        {
            if (favorites.exists())
            {
                InputStream is = new BufferedInputStream(new FileInputStream(
                            favorites));
                Reader reader = new BufferedReader(new InputStreamReader(is,
                            "UTF-8"));
                final List<TitledURLEntry> li = new ArrayList<TitledURLEntry>();

                SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
                InputSource inputSource = new InputSource(reader);

                final DefaultHandler dh = new DefaultHandler()
                    {
                        @Override
                        public void startElement(String uri, String localName,
                            String name, Attributes attributes)
                            throws SAXException
                        {
                            super.startElement(uri, localName, name, attributes);

                            if ("entry".equals(name))
                            {
                                TitledURLEntry tue = null;
                                String title = attributes.getValue("title");
                                String url = attributes.getValue("url");

                                if ((title != null) && (url != null))
                                {
                                    tue = new TitledURLEntry(title, url);
                                    li.add(tue);
                                }
                            }
                        }
                        ;
                    };

                parser.parse(inputSource, dh);

                is.close();
                is.close();

                return li;
            }
            else
            {
                writeDefaultFavorites();
            }
        }
        catch (Exception e)
        {
            System.err.println("Rebuilding bookmarks");
            e.printStackTrace();

            writeDefaultFavorites();
        }

        return new ArrayList<TitledURLEntry>();
    }

    private void writeDefaultFavorites()
    {
        File favorites = VFSJFileChooserConstants.BOOKMARKS_FILE;

        try
        {
            writeToFile(favorites, "<entries></entries>");
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }

    private void writeToFile(File dest, String str) throws IOException
    {
        OutputStream fos = new FileOutputStream(dest);
        OutputStream bos = new BufferedOutputStream(fos);
        Writer osw = new OutputStreamWriter(bos, "UTF-8");
        Writer writer = new BufferedWriter(osw);
        writer.write(str);

        writer.flush();
        writer.close();

        bos.flush();
        bos.close();

        fos.flush();
        fos.close();
    }

    // end AbstractTableModel implementation
    public void save()
    {
        StringBuilder sb = new StringBuilder("<entries>");

        Iterator<TitledURLEntry> it = entries.listIterator();

        while (it.hasNext())
        {
            TitledURLEntry b = it.next();

            if ((b == null) ||
                    ((b.getTitle() == null) || (b.getTitle().length() == 0)))
            {
                it.remove();
            }
            else
            {
                sb.append("<entry title=\"").append(b.getTitle()).append("\" ")
                  .append("url=\"").append(b.getURL()).append("\" />");
            }
        }

        sb.append("</entries>");

        try
        {
            File favorites = VFSJFileChooserConstants.BOOKMARKS_FILE;
            writeToFile(favorites, sb.toString());
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
