/*
 * Protocol constants
 * 
 * Copyright (C) 2005-2008 Yves Zoundi
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * under the License.
 */
package net.sf.vfsjfilechooser.accessories.connection;


/**
 * Enumeration holding protocol constants
 * @author Yves Zoundi<yveszoundi at users dot sf dot net>
 * @version 0.0.1
 */
public enum Protocol
{
	// Protocol constants
    SMB("SMB", 445, -1), 			// Samba protocol
    SFTP("SFTP", 22, -1), 			// SFTP protocol
    FTP("FTP", 21, 990), 			// FTP protocol
    WEBDAV("WEBDAV", 9800, 9802),   // Webdav protocol
    HTTP("HTTP", 80, 443);			// HTTP protocol
    
    private final String name;  // displayed name
    private final Integer port; // port number
    private final int sslPort;

    /**
     * Create a new protocol
     * @param name The name of the protocol
     * @param port The port used by the protocol
     */
    Protocol(final String name, final int port, final int sslPort)
    {
        this.name = name;
        this.port = port;
        this.sslPort = sslPort;
    }

    /**
     * Returns the protocol name
     * @return the protocol name
     */
    public final String getName()
    {
        return name;
    }

    /**
     * Returns the protocol port number
     * @return the protocol port number
     */
    public final int getPort()
    {
        return port;
    }
    
    /**
     * Returns the protocol port number over SSL
     * @return the protocol port number over SSL
     */
    public final int getSslPort(){
    	return this.sslPort;
    }

    @Override
    public String toString()
    {
        return this.name;
    }
}
