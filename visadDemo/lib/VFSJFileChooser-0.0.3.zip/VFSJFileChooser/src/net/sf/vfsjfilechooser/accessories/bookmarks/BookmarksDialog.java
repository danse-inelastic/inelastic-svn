/*
 *
 * Copyright (C) 2005-2008 Yves Zoundi
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * under the License.
 */
package net.sf.vfsjfilechooser.accessories.bookmarks;

import net.sf.vfsjfilechooser.VFSJFileChooser;
import net.sf.vfsjfilechooser.utils.VFSUtils;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;


/**
 * The bookmarks dialog
 * @author Dirk Moebius (JEdit)
 * @author Yves Zoundi <yveszoundi at users dot sf dot net>
 * @version 0.0.1
 */
@SuppressWarnings("serial")
public class BookmarksDialog extends JDialog
{
    private JScrollPane scrollPane;
    private JTable table;
    private JButton bOpen;
    private JButton bOk;
    private JButton bCancel;
    private JButton bAdd;
    private JButton bDelete;
    private JButton bMoveUp;
    private JButton bMoveDown;
    private Bookmarks model;
    private VFSJFileChooser chooser;
    private final Dimension tableSize = new Dimension(350, 200);

    public BookmarksDialog(Frame parent, VFSJFileChooser chooser)
    {
        super(parent, "Bookmarks", true);

        this.chooser = chooser;

        model = new Bookmarks();
        table = new JTable(model);
        scrollPane = new JScrollPane(table);

        table.setPreferredScrollableViewportSize(tableSize);
        table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        bOk = new JButton("OK");

        bCancel = new JButton("Cancel");

        bOpen = new JButton("Open");
        bOpen.setIcon(new ImageIcon(getClass()
                                        .getResource("/net/sf/vfsjfilechooser/plaf/icons/document-open.png")));
        bOpen.setHorizontalAlignment(SwingConstants.LEFT);

        bAdd = new JButton("Add");
        bAdd.setIcon(new ImageIcon(getClass()
                                       .getResource("/net/sf/vfsjfilechooser/plaf/icons/list-add.png")));
        bAdd.setHorizontalAlignment(SwingConstants.LEFT);

        bDelete = new JButton("Delete");
        bDelete.setIcon(new ImageIcon(getClass()
                                          .getResource("/net/sf/vfsjfilechooser/plaf/icons/list-remove.png")));
        bDelete.setHorizontalAlignment(SwingConstants.LEFT);

        bMoveUp = new JButton("Move up");
        bMoveUp.setIcon(new ImageIcon(getClass()
                                          .getResource("/net/sf/vfsjfilechooser/plaf/icons/go-up.png")));
        bMoveUp.setHorizontalAlignment(SwingConstants.LEFT);

        bMoveDown = new JButton("Move down");
        bMoveDown.setIcon(new ImageIcon(getClass()
                                            .getResource("/net/sf/vfsjfilechooser/plaf/icons/go-down.png")));
        bMoveDown.setHorizontalAlignment(SwingConstants.LEFT);

        final ActionHandler ah = new ActionHandler();

        bOpen.addActionListener(ah);
        bOk.addActionListener(ah);
        bCancel.addActionListener(ah);
        bAdd.addActionListener(ah);
        bDelete.addActionListener(ah);
        bMoveUp.addActionListener(ah);
        bMoveDown.addActionListener(ah);

        final Box south = Box.createHorizontalBox();
        south.add(Box.createHorizontalGlue());
        south.add(bOk);
        south.add(Box.createHorizontalStrut(20));
        south.add(bCancel);
        south.add(Box.createHorizontalGlue());

        final JPanel buttons = new JPanel(new GridLayout(0, 1, 5, 5));

        buttons.add(bAdd);
        buttons.add(bDelete);
        buttons.add(bOpen);
        buttons.add(Box.createVerticalStrut(10));
        buttons.add(bMoveUp);
        buttons.add(bMoveDown);

        JPanel east = new JPanel();
        east.add(buttons, BorderLayout.NORTH);
        east.add(new JPanel(), BorderLayout.CENTER); // don't ask

        getContentPane().setLayout(new BorderLayout(10, 10));

        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(south, BorderLayout.SOUTH);
        getContentPane().add(east, BorderLayout.EAST);

        getRootPane().setDefaultButton(bOk);

        getRootPane()
            .setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10,
                UIManager.getColor("Panel.background")));

        pack();
    }

    public Bookmarks getModel()
    {
        return model;
    }

    public void ok()
    {
        model.save();
        setVisible(false);
    }

    public void cancel()
    {
        setVisible(false);
    }

    private class ActionHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent actionEvent)
        {
            JButton button = (JButton) actionEvent.getSource();

            if (button.equals(bAdd))
            {
                model.add(new TitledURLEntry("", ""));
            }
            else if (button.equals(bOpen))
            {
                final int row = table.getSelectedRow();

                if (row != -1)
                {
                    Thread worker = new Thread()
                        {
                            public void run()
                            {
                                setCursor(Cursor.getPredefinedCursor(
                                        Cursor.WAIT_CURSOR));

                                TitledURLEntry aTitledURLEntry = model.getEntry(row);

                                chooser.setCurrentDirectory(VFSUtils.resolveFileObject(
                                        aTitledURLEntry.getURL()));
                                setCursor(Cursor.getDefaultCursor());
                                cancel();
                            }
                        };

                    worker.setPriority(Thread.MIN_PRIORITY);
                    SwingUtilities.invokeLater(worker);
                }
            }
            else if (button.equals(bDelete))
            {
                int[] rows = table.getSelectedRows();

                if (rows.length == 0)
                {
                    return;
                }
                else
                {
                    for (int i = rows.length - 1; i >= 0; i--)
                    {
                        model.delete(rows[i]);
                    }
                }
            }
            else if (button.equals(bMoveUp))
            {
                int[] rows = table.getSelectedRows();

                if (rows.length == 0)
                {
                    return;
                }
                else if (rows.length > 1)
                {
                    return;
                }
                else if (rows[0] > 0)
                {
                    model.moveup(rows[0]);
                    table.setRowSelectionInterval(rows[0] - 1, rows[0] - 1);
                }
            }
            else if (button.equals(bMoveDown))
            {
                int[] rows = table.getSelectedRows();

                if (rows.length == 0)
                {
                    return;
                }
                else if (rows.length > 1)
                {
                    return;
                }
                else if (rows[0] < (model.getRowCount() - 1))
                {
                    model.movedown(rows[0]);
                    table.setRowSelectionInterval(rows[0] + 1, rows[0] + 1);
                }
            }
            else if (button.equals(bOk))
            {
                ok();
            }
            else if (button.equals(bCancel))
            {
                cancel();
            }
        }
    } // inner class ActionHandler
}
