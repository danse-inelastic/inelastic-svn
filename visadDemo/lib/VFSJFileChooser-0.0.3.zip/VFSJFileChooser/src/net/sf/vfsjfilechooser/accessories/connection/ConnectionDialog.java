/*
 *
 * Copyright (C) 2005-2008 Yves Zoundi
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * under the License.
 */
package net.sf.vfsjfilechooser.accessories.connection;

import net.sf.vfsjfilechooser.VFSJFileChooser;
import net.sf.vfsjfilechooser.accessories.bookmarks.BookmarksDialog;
import net.sf.vfsjfilechooser.accessories.bookmarks.TitledURLEntry;
import net.sf.vfsjfilechooser.accessories.connection.Credentials.Builder;
import net.sf.vfsjfilechooser.utils.SpringUtilities;
import net.sf.vfsjfilechooser.utils.VFSUtils;

import org.apache.commons.vfs.FileObject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.text.NumberFormat;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SpringLayout;


/**
 * The connection dialog
 * @author Yves Zoundi <yveszoundi at users dot sf dot net>
 * @version 0.0.1
 */
@SuppressWarnings("serial")
public final class ConnectionDialog extends JDialog
{
    private JLabel usernameLabel;
    private JLabel defaultRemotePathLabel;
    private JLabel passwordLabel;
    private JLabel protocolLabel;
    private JLabel portLabel;
    private JLabel hostnameLabel;
    private JTextField hostnameTextField;
    private JTextField defaultRemotePathTextField;
    private JTextField usernameTextField;
    private JPasswordField passwordTextField;
    private JFormattedTextField portTextField;
    private JLabel dummySllLabel;
    private JCheckBox sslOption;
    private JComboBox protocolList;
    private JComponent buttonsPanel;
    private JButton connectButton;
    private DefaultComboBoxModel protocolModel;
    private JButton cancelButton;
    private JComponent centerPanel;
    private VFSJFileChooser fileChooser;
    private BookmarksDialog bookmarksDialog;
    private Thread currentWorker;

    /**
     * @param parent
     * @param m_dialog
     * @param chooser
     */
    public ConnectionDialog(Frame parent, BookmarksDialog m_dialog,
        VFSJFileChooser chooser)
    {
        super(parent,
            "Connect to server(Information added to bookmarks for now)", true);

        this.fileChooser = chooser;
        this.bookmarksDialog = m_dialog;

        initComponents();
        initListeners();
    }

    private void initComponents()
    {
        this.setLayout(new BorderLayout());

        initCenterPanelComponents();
        initBottomPanelComponents();

        this.add(this.buttonsPanel, BorderLayout.SOUTH);
        this.add(this.centerPanel, BorderLayout.CENTER);

        pack();
    }

    private void initCenterPanelComponents()
    {
        // create the panel
        this.centerPanel = new JPanel(new SpringLayout());
        this.centerPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));

        // create the components
        this.hostnameLabel = new JLabel("Host");
        this.hostnameLabel.setForeground(Color.RED);
        this.hostnameTextField = new JTextField(25);

        this.portLabel = new JLabel("Port number");
        this.portTextField = new JFormattedTextField(NumberFormat.getInstance());

        this.protocolLabel = new JLabel("Protocol");
        this.protocolModel = new DefaultComboBoxModel(Protocol.values());
        this.protocolList = new JComboBox(protocolModel);

        this.usernameLabel = new JLabel("Username");
        this.usernameTextField = new JTextField(20);

        this.passwordLabel = new JLabel("Password");
        this.passwordTextField = new JPasswordField(12);

        this.dummySllLabel = new JLabel();
        this.sslOption = new JCheckBox("Use SSL");

        this.defaultRemotePathLabel = new JLabel("Default Remote Path");
        this.defaultRemotePathTextField = new JTextField(20);

        // Add the components to the panel
        this.centerPanel.add(this.hostnameLabel);
        this.centerPanel.add(this.hostnameTextField);

        this.centerPanel.add(this.portLabel);
        this.centerPanel.add(this.portTextField);

        this.centerPanel.add(this.protocolLabel);
        this.centerPanel.add(this.protocolList);

        this.centerPanel.add(this.dummySllLabel);
        this.centerPanel.add(this.sslOption);

        this.centerPanel.add(this.usernameLabel);
        this.centerPanel.add(this.usernameTextField);

        this.centerPanel.add(this.passwordLabel);
        this.centerPanel.add(this.passwordTextField);

        this.centerPanel.add(this.defaultRemotePathLabel);
        this.centerPanel.add(this.defaultRemotePathTextField);

        SpringUtilities.makeGrid(centerPanel, 7, 2, 3, 3, 4, 4);
    }

    private void initListeners()
    {
        this.cancelButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    if (currentWorker != null)
                    {
                        if (currentWorker.isAlive())
                        {
                            currentWorker.interrupt();
                            setCursor(Cursor.getDefaultCursor());
                        }
                    }

                    setVisible(false);
                }
            });

        this.connectButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    currentWorker = new Thread()
                            {
                                public void run()
                                {
                                    StringBuilder error = new StringBuilder();
                                    FileObject fo = null;

                                    setCursor(Cursor.getPredefinedCursor(
                                            Cursor.WAIT_CURSOR));

                                    try
                                    {
                                        String m_username = usernameTextField.getText();
                                        String m_defaultRemotePath = defaultRemotePathTextField.getText();
                                        char[] m_password = passwordTextField.getPassword();
                                        String m_hostname = hostnameTextField.getText();
                                        String m_protocol = protocolList.getSelectedItem()
                                                                        .toString();
                                        int m_port = Integer.valueOf(portTextField.getValue()
                                                                                  .toString());

                                        Builder credentialsBuilder = Credentials.newBuilder(m_hostname)
                                                                                .defaultRemotePath(m_defaultRemotePath)
                                                                                .username(m_username)
                                                                                .password(m_password)
                                                                                .protocol(m_protocol)
                                                                                .port(m_port);

                                        Credentials credentials = credentialsBuilder.build();

                                        String uri = credentials.toFileObjectURL();

                                        if (isInterrupted())
                                        {
                                            return;
                                        }

                                        fo = VFSUtils.resolveFileObject(uri);
                                    }
                                    catch (Exception err)
                                    {
                                        error.append(err.getMessage());
                                        setCursor(Cursor.getDefaultCursor());
                                    }

                                    if ((error.length() > 0) || (fo == null))
                                    {
                                        error.append("Impossible to connect!");

                                        JOptionPane.showMessageDialog(null,
                                            error, "Error",
                                            JOptionPane.ERROR_MESSAGE);
                                        setCursor(Cursor.getDefaultCursor());

                                        return;
                                    }

                                    if (isInterrupted())
                                    {
                                        return;
                                    }

                                    fileChooser.setCurrentDirectory(fo);

                                    setCursor(Cursor.getDefaultCursor());

                                    resetFields();

                                    if (bookmarksDialog != null)
                                    {
                                        String bTitle = fo.getName()
                                                          .getBaseName();

                                        if (bTitle.trim().equals(""))
                                        {
                                            bTitle = fo.getName().toString();
                                        }

                                        String bURL = fo.getName().getURI();
                                        bookmarksDialog.getModel()
                                                       .add(new TitledURLEntry(
                                                bTitle, bURL));
                                        bookmarksDialog.getModel().save();
                                    }

                                    setVisible(false);
                                }
                            };

                    currentWorker.setPriority(Thread.MIN_PRIORITY);
                    currentWorker.start();
                }
            });

        this.protocolList.addItemListener(new ItemListener()
            {
                public void itemStateChanged(ItemEvent e)
                {
                    if (e.getStateChange() == ItemEvent.SELECTED)
                    {
                        selectPortNumber();
                    }
                }
            });

        this.sslOption.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent actionEvent)
                {
                    selectPortNumber();
                }
            });

        this.protocolList.setSelectedItem(Protocol.FTP);
    }

    private void selectPortNumber()
    {
        Protocol protocol = (Protocol) protocolList.getSelectedItem();

        if (sslOption.isSelected())
        {
            int sslPort = protocol.getSslPort();

            if (sslPort != -1)
            {
                portTextField.setValue(sslPort);
            }
        }
        else
        {
            portTextField.setValue(protocol.getPort());
        }
    }

    private void resetFields()
    {
        hostnameTextField.setText("");
        sslOption.setSelected(false);
        protocolList.setSelectedItem(Protocol.FTP);
        usernameTextField.setText("");
        passwordTextField.setText("");
        defaultRemotePathTextField.setText("");
    }

    private void initBottomPanelComponents()
    {
        this.buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        this.cancelButton = new JButton("Cancel");
        this.connectButton = new JButton("Connect");

        this.buttonsPanel.add(this.connectButton);
        this.buttonsPanel.add(this.cancelButton);
    }
}
