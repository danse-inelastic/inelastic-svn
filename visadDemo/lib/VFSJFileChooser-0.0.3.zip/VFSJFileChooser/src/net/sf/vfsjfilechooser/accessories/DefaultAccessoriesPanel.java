/*
 *
 * Copyright (C) 2005-2008 Yves Zoundi
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * under the License.
 */
package net.sf.vfsjfilechooser.accessories;

import net.sf.vfsjfilechooser.VFSJFileChooser;
import net.sf.vfsjfilechooser.accessories.bookmarks.BookmarksDialog;
import net.sf.vfsjfilechooser.accessories.bookmarks.TitledURLEntry;
import net.sf.vfsjfilechooser.accessories.connection.ConnectionDialog;
import net.sf.vfsjfilechooser.utils.SwingCommonsUtilities;

import org.apache.commons.vfs.FileObject;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;


/**
 * <p>The default accessory panel you could add
 * It contains a bookmarks manager and the a connection dialog</p>
 * @author Yves Zoundi <yveszoundi at users dot sf dot net>
 * @version 0.0.1
 */
@SuppressWarnings("serial")
public final class DefaultAccessoriesPanel extends JComponent
{
    private JButton bookmarksButton;
    private JButton localFSButton;
    private JButton connectionsButton;
    private BookmarksDialog dialog;
    private ConnectionDialog connectionDialog;
    private JComponent buttonsPanel;
    private JPopupMenu menu;
    private JMenuItem addItem;
    private JMenuItem manageItem;
    private VFSJFileChooser fileChooser;

    /**
     * Create an accessory panel
     * @param fileChooser The file dialog
     */
    public DefaultAccessoriesPanel(final VFSJFileChooser fileChooser)
    {
        setLayout(new BorderLayout());

        this.fileChooser = fileChooser;

        initBorder();
        initComponents();
        initListeners();
    }

    void initBorder()
    {
        Border outsideBorder = new EtchedBorder();
        Border insideBorder = new EmptyBorder(2, 4, 0, 2);

        Border insideBorder1 = new CompoundBorder(outsideBorder, insideBorder);
        Border outsideBorder1 = new EmptyBorder(0, 2, 0, 2);

        setBorder(new CompoundBorder(outsideBorder1, insideBorder1));
    }

    void initComponents()
    {
        this.buttonsPanel = new JPanel();
        this.buttonsPanel.setLayout(new GridLayout(0, 1, 3, 3));

        this.bookmarksButton = new JButton("Bookmarks");
        this.bookmarksButton.setIcon(new ImageIcon(getClass().getResource("/net/sf/vfsjfilechooser/plaf/icons/book.png")));
        this.bookmarksButton.setHorizontalAlignment(SwingConstants.LEFT);
        
        this.connectionsButton = new JButton("Connection");
        this.connectionsButton.setIcon(new ImageIcon(getClass().getResource("/net/sf/vfsjfilechooser/plaf/icons/connect.png")));
        this.connectionsButton.setHorizontalAlignment(SwingConstants.LEFT);
        
        this.localFSButton = new JButton("Local files");
        this.localFSButton.setIcon(new ImageIcon(getClass().getResource("/net/sf/vfsjfilechooser/plaf/icons/drive.png")));
        this.localFSButton.setHorizontalAlignment(SwingConstants.LEFT);
        
        this.buttonsPanel.add(this.bookmarksButton);
        this.buttonsPanel.add(Box.createVerticalStrut(20));
        this.buttonsPanel.add(this.connectionsButton);
        this.buttonsPanel.add(Box.createVerticalStrut(20));
        this.buttonsPanel.add(this.localFSButton);

        add(buttonsPanel, BorderLayout.NORTH);
        add(new JPanel(), BorderLayout.CENTER);

        final Frame c = (Frame) SwingUtilities.getWindowAncestor(fileChooser);

        this.dialog = new BookmarksDialog(c, fileChooser);
        this.dialog.setTitle("Bookmarks manager");

        this.connectionDialog = new ConnectionDialog(c, dialog, fileChooser);

        this.menu = new JPopupMenu();

        this.addItem = menu.add("Add");
        this.manageItem = menu.add("Manage");
    }

    void initListeners()
    {
        this.connectionsButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    connectionDialog.setLocationRelativeTo(fileChooser);
                    connectionDialog.setVisible(true);
                }
            });

        this.localFSButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    fileChooser.setCurrentDirectory(SwingCommonsUtilities.getVFSFileChooserDefaultDirectory());
                }
            });

        this.bookmarksButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    menu.show(bookmarksButton, 0, bookmarksButton.getHeight());
                }
            });

        this.manageItem.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    dialog.setLocationRelativeTo(fileChooser);
                    dialog.setVisible(true);
                }
            });

        this.addItem.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    FileObject fo = fileChooser.getCurrentDirectory();
                    String name = fo.getName().getBaseName();

                    if (name.trim().equals(""))
                    {
                        name = fo.toString();
                    }

                    String uri = fo.getName().getURI();

                    TitledURLEntry bookmarkEntry = new TitledURLEntry(name, uri);

                    dialog.getModel().add(bookmarkEntry);
                }
            });
    }
}
